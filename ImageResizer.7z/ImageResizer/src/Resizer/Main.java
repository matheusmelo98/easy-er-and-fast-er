package Resizer;

import java.io.File;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Pane;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

public class Main extends Application {

    private Stage stage;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        this.stage = stage;
        stage.setTitle("Resizer");
        Image image = new Image(getClass().getResourceAsStream("fofo.png"));
        stage.getIcons().add(image);
        Pane root = new Pane();
        Scene scene = new Scene(root, 800, 400, Color.BLACK);
        stage.setScene(scene);
        /*--------------------------------------------------*/
        HBox topo = new HBox();
        topo.setPrefWidth(stage.getWidth());
        topo.setStyle("-fx-background-color:grey;"
                + "-fx-text-fill:black;"
                + "-fx-text-align:center;");
        topo.setPrefHeight(100.0);
        topo.setLayoutY(0.0);
        topo.setLayoutX(0.0);
        topo.setSpacing(20.0);
        topo.setPadding(new Insets(8, 8, 8, 8));
        topo.setOpacity(1.0);
        Button open = new Button("Open");
        Button close = new Button("Close");
        topo.getChildren().addAll(open, close);
        /*---------------------------------------------------*/
        HBox meio = new HBox();
        meio.setPrefWidth(stage.getWidth() / 2);
        meio.setStyle("-fx-background-color:grey;"
                + "-fx-text-fill:black;"
                + "-fx-text-align:center;");
        meio.setPrefHeight(stage.getHeight() - 100);
        meio.setLayoutX(0.0);
        meio.setLayoutY(100.0);
        meio.setSpacing(20);
        meio.setOpacity(1.0);
        meio.setPadding(new Insets(8, 8, 8, 8));
        RadioButton radio = new RadioButton();
        root.getChildren().add(topo);
        root.getChildren().add(meio);
        /*---------------------------------------------------*/
        close.setOnAction(e -> {
            System.exit(0);
        });
        open.setOnAction(e -> {
            FileChooser fc = new FileChooser();
            FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("IMAGE files (*.png)", "*.png", "(*.jpg)", "*.jpg", "(*.gif)", "*.gif", "(*.jpeg)", "*.jpeg");
            fc.getExtensionFilters().add(extFilter);
            String file = fc.showOpenDialog(stage).getAbsolutePath();
            Image imagem = new Image(getClass().getResourceAsStream(file));
            ImageView view = new ImageView(imagem);
            view.setPreserveRatio(true);
            view.setFitHeight(meio.getWidth());
            view.setFitWidth(meio.getHeight());
            meio.getChildren().add(view);
        });
        /*---------------------------------------------------*/
        stage.show();
        stage.setResizable(false);
    }
}
