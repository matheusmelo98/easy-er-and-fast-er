package calculator;

import java.util.ArrayList;

public class Calculator {

    private int first;
    private int second;
    public String operator = null;
    final EntradeDeTexto entrance = new EntradeDeTexto();

    public void setFirst(ArrayList<Integer> first) {
        int[] aux = new int[10];
        int multiplier = 1;
        for (int i = 0; i < first.size(); i++) {
            aux[i] = first.get(i);
            multiplier = multiplier * 10;
        }
        long valor = 0;
        for (int i = 0; i < aux.length; i++) {
            valor += aux[i] * multiplier;
            multiplier = multiplier / 10;
        }
    }

    public void setSecond(ArrayList<Integer> second) {
        int[] aux = new int[10];
        int multiplier = 1;
        for (int i = 0; i < second.size(); i++) {
            aux[i] = second.get(i);
            multiplier = multiplier * 10;
        }
        long valor = 0;
        for (int i = 0; i < aux.length; i++) {
            valor += aux[i] * multiplier;
            multiplier = multiplier / 10;
        }
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public void getResults() {
        int value = 0;
        switch (operator) {
            case "+":
                value = first + second;
                break;
            case "-":
                value = first - second;
                break;
            case "/":
                value = first / second;
                break;
            case "*":
                value = first * second;
                break;
        }
        entrance.value = value;
    }

}
