package calculator;

import javafx.scene.layout.Pane;
import java.util.ArrayList;

public class Funcionalidades {

    final Pane pane = new Pane();
    final EntradeDeTexto entrance = new EntradeDeTexto();
    final Calculator calculator = new Calculator();
    final mainCalculator calc = new mainCalculator();
    final PrimeiraLinha first = new PrimeiraLinha();
    final SegundaLinha second = new SegundaLinha();
    final TerceiraLinha third = new TerceiraLinha();
    final QuartaLinha fourth = new QuartaLinha();
    ArrayList<Integer> lista = new ArrayList<>();

    private boolean pressed = false;
    private boolean resultados = false;
    int counter = 0;

    public void setOn() {
        calc.one.setOnAction(e -> {
            lista.add(1);
            entrance.value = 1;
        });
        calc.two.setOnAction(e -> {
            lista.add(2);
            entrance.value = 2;
        });
        calc.three.setOnAction(e -> {
            lista.add(3);
            entrance.value = 3;
        });
        calc.mais.setOnAction(e -> {
            lista.clear();
            calculator.setOperator("+");
            pressed = true;
            counter++;
        });
        calc.four.setOnAction(e -> {
            lista.add(4);
            entrance.value = 4;
        });
        calc.five.setOnAction(e -> {
            lista.add(5);
            entrance.value = 5;
        });
        calc.six.setOnAction(e -> {
            lista.add(6);
            entrance.value = 6;
        });
        calc.menos.setOnAction(e -> {
            lista.clear();
            calculator.setOperator("-");
            pressed = true;
            counter++;
        });
        calc.seven.setOnAction(e -> {
            lista.add(7);
            entrance.value = 7;
        });
        calc.eight.setOnAction(e -> {
            lista.add(8);
            entrance.value = 8;
        });
        calc.nine.setOnAction(e -> {
            lista.add(9);
            entrance.value =9;
        });
        calc.vezes.setOnAction(e -> {
            lista.clear();
            calculator.setOperator("*");
            pressed = true;
            counter++;
        });
        calc.zero.setOnAction(e -> {
            lista.add(10);
            entrance.value=0;
        });
        calc.div.setOnAction(e -> {
            lista.clear();
            calculator.setOperator("/");
            pressed = true;
            counter++;
        });
        calc.result.setOnAction(e -> {
            lista.clear();
            pressed = true;
            resultados = true;
        });
        calc.clear.setOnAction(e -> {
            lista.clear();
            pressed = true;
        });
    }
    public void isPressed(){
        if(counter==1){
            calculator.setFirst(lista);
        }else if(counter==2){
            calculator.setSecond(lista);
        }else{
            setOn();
        }
    }
    public void isResult(){
        if(resultados==true){
            calculator.getResults();
        }else{
            setOn();
        }
    }

}
