package calculator;

import static javafx.application.Application.launch;
import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.scene.control.Button;
import javafx.application.Application;
import javafx.scene.layout.VBox;
import javafx.scene.control.TextField;
import javafx.geometry.Insets;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

public class mainCalculator extends Application {

    final public Button one = new Button("1");
    final public Button two = new Button("2");
    final public Button three = new Button("3");
    final public Button four = new Button("4");
    final public Button five = new Button("5");
    final public Button six = new Button("6");
    final public Button seven = new Button("7");
    final public Button eight = new Button("8");
    final public Button nine = new Button("9");
    final public Button zero = new Button("0");
    final public Button mais = new Button("+");
    final public Button menos = new Button("-");
    final public Button vezes = new Button("*");
    final public Button div = new Button("/");
    final public Button result = new Button("=");
    final public Button clear = new Button("clear");

    private Stage stage;
    final private EntradeDeTexto digita = new EntradeDeTexto();
    final private PrimeiraLinha first = new PrimeiraLinha();
    final private SegundaLinha second = new SegundaLinha();
    final private TerceiraLinha third = new TerceiraLinha();
    final private QuartaLinha fourth = new QuartaLinha();

    final private Funcionalidades func = new Funcionalidades();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        this.stage = stage;
        stage.setTitle("Calculadora");
        Image image = new Image(getClass().getResourceAsStream("root.png"));
        stage.getIcons().add(image);

        final Pane pane = new Pane();
        final Scene scene = new Scene(pane, 400, 600, Color.GRAY);
        scene.setRoot(pane);

        digita.start(stage);
        first.start(stage);
        second.start(stage);
        third.start(stage);
        fourth.start(stage);
        
        digita.caixa.setMinWidth(stage.getWidth());
        one.setMinWidth(stage.getWidth() / 4);
        two.setMinWidth(stage.getWidth() / 4);
        three.setMinWidth(stage.getWidth() / 4);
        mais.setMinWidth(stage.getWidth() / 4);
        four.setMinWidth(stage.getWidth() / 4);
        five.setMinWidth(stage.getWidth() / 4);
        six.setMinWidth(stage.getWidth() / 4);
        menos.setMinWidth(stage.getWidth() / 4);
        seven.setMinWidth(stage.getWidth() / 4);
        eight.setMinWidth(stage.getWidth() / 4);
        nine.setMinWidth(stage.getWidth() / 4);
        vezes.setMinWidth(stage.getWidth() / 4);
        zero.setMinWidth(stage.getWidth() / 4);
        div.setMinWidth(stage.getWidth() / 4);
        result.setMinWidth(stage.getWidth() / 4);
        clear.setMinWidth(stage.getWidth() / 4);

        pane.getChildren().add(digita.caixa);
        pane.getChildren().add(first.caixa);
        pane.getChildren().add(second.caixa);
        pane.getChildren().add(third.caixa);
        pane.getChildren().add(fourth.caixa);

        func.setOn();
        func.isPressed();
        func.isResult();

        stage.setResizable(true);
        stage.setScene(scene);
        stage.show();

    }

}
