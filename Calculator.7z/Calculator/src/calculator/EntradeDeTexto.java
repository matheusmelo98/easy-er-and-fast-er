
package calculator;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.geometry.Insets;
import javafx.scene.paint.Color;
import javafx.scene.layout.Pane;
import javafx.scene.control.TextField;
import java.util.ArrayList;
public class EntradeDeTexto {
    final public HBox caixa = new HBox();
    final Pane pane = new Pane();
    Calculator calc = new Calculator();
    Funcionalidades func = new Funcionalidades();
    public int value;
    
    public void start(final Stage stage) throws Exception{
        TextField linhaTexto = new TextField();
        String valor = String.valueOf(value);
        linhaTexto.setText(valor);
        
    }
    public void setValue(int value){
        this.value=value;
    }
    
}
