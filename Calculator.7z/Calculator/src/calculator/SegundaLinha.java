package calculator;

import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.geometry.Insets;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class SegundaLinha {

    final public HBox caixa = new HBox();
    final Pane pane = new Pane();

    public void start(final Stage stage) throws Exception {

    }

    public void adiciona(javafx.scene.control.Button button) {
        caixa.getChildren().add(button);
    }
}
